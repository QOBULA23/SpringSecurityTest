package com.workshop.nika;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NikaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NikaApplication.class, args);
	}

}
